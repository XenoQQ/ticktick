import Todoapp from './components/todoapp';
import { initializeApp } from 'firebase/app';
import { getAnalytics } from 'firebase/analytics';

const firebaseConfig = {
    apiKey: 'AIzaSyD0AukGZt1UozbjQl-FBR9UO5hbVsGVS5M',
    authDomain: 'todolist-c137.firebaseapp.com',
    projectId: 'todolist-c137',
    storageBucket: 'todolist-c137.appspot.com',
    messagingSenderId: '428077446248',
    appId: '1:428077446248:web:d1535f15b948e18bdc77dd',
};
const app = initializeApp(firebaseConfig);
getAnalytics(app);

const App = () => {
    return <Todoapp />;
};

export default App;
