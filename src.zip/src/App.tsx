import Todoapp from './components/todoapp';

const App = () => {
    return <Todoapp />;
};

export default App;
