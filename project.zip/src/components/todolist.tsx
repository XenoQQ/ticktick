import React from 'react';
import styled from 'styled-components';
import TodoItem from './todoitem';
import { useSelector } from 'react-redux';
import { RootState } from '../store/store';
import { TodoItemProps, PriorityMap } from '../controls/types';

const TodolistContainer = styled.div`
    display: flex;

    flex-direction: column;
`;

const Grouptitle = styled.div`
    margin: 5px 0 0 0;
    padding: 0 0 0 5px;

    font-family: 'Ubuntu', sans-serif;
    color: #757575;
    font-size: 15px;
`;

const TodoList: React.FC = () => {
    const todos = useSelector((state: RootState) => state.todos);
    const groupSwitch = useSelector((state: RootState) => state.groupSwitch);

    let unusedvar = 42;

    const groupTodos = (groupCase: string) => {
        const groupKey = (key: string) => {
            return todos.reduce(
                (acc: Record<string, TodoItemProps[]>, item) => {
                    const groupValues = Array.isArray(item.data[key]) ? item.data[key] : [item.data[key]];
                    groupValues.forEach((groupvalue: string) => {
                        if (!acc[groupvalue]) {
                            acc[groupvalue] = [];
                        }
                        acc[groupvalue].push(item);
                    });
                    return acc;
                },
                {} as Record<string, TodoItemProps[]>,
            );
        };

        switch (groupCase) {
            case 'date':
                return groupKey('timeOfCreation');
            case 'priority':
                return groupKey('priority');
            case 'tag':
                return groupKey('tags');
            case 'none':
            default:
                return groupKey('');
        }
    };

    const groupKeyTranslations: PriorityMap = {
        none: 'Нет',
        low: 'Не то чтобы очень важно',
        medium: 'Ну так, средней важности',
        high: 'Пиздец как важно, прямо очень!',
    };

    type GroupedTodos = [string, TodoItemProps[]][];

    const groupedTodos: GroupedTodos = Object.entries(groupTodos(groupSwitch));

    return (
        <>
            {groupedTodos.map(([key, group]) => (
                <TodolistContainer key={key}>
                    {key && key !== 'undefined' && <Grouptitle>{groupKeyTranslations[key]}</Grouptitle>}
                    {group.map((todo) => (
                        <TodoItem key={todo.key} data={todo.data} />
                    ))}
                </TodolistContainer>
            ))}
        </>
    );
};

export default TodoList;
